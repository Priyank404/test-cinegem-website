// ClassicEComVisuals.jsx
import { ServicePageLayout } from "@/components/shared/ServicePageLayout";
import { BackToVault } from "@/components/shared/BackToVault";

const images = [
  { src: "/1.png", alt: "Front view", label: "Front" },
  { src: "/2.png", alt: "Side view", label: "Side" },
  { src: "/3.png", alt: "Angle view", label: "Angle" },
  { src: "/4.png", alt: "Detail view", label: "Detail" },
];

// Section 2 — second product set (4-image row + video below)
const images2 = [
  { src: "/5.png", alt: "Front view", label: "Front" },
  { src: "/6.png", alt: "Side view", label: "Side" },
  { src: "/7.png", alt: "Angle view", label: "Angle" },
  { src: "/8.png", alt: "Detail view", label: "Detail" },
];

/* ═══════════════════════════════════════════════════════════════════════
   PRIMITIVES
═══════════════════════════════════════════════════════════════════════ */

function ImageTile({ img }) {
  return (
    <div
      className="
        relative
        w-full h-full
        overflow-hidden
        bg-[#FAF9F6]
        border border-[#c4c7c7]/40
        gallery-shadow
        hover:-translate-y-1
        transition-transform duration-300
      "
    >
      <img src={img.src} alt={img.alt} className="w-full h-full object-cover" />
      <span
        className="
          absolute
          bottom-2 left-2
          font-[Manrope]
          text-[9px]
          tracking-[0.15em]
          font-semibold
          uppercase
          px-2 py-1
          bg-white/80
          text-[#444748]
        "
      >
        {img.label}
      </span>
    </div>
  );
}

function VideoPlayer({ videoSrc, className = "" }) {
  return (
    <div
      className={`
        relative
        flex items-center justify-center
        bg-[#0d0d0d]
        overflow-hidden
        border border-[#c4c7c7]/20
        ${className}
      `}
    >
      {videoSrc ? (
        <video
          src={videoSrc}
          className="absolute inset-0 w-full h-full object-cover"
          controls
          controlsList="nodownload noplaybackrate nofullscreen"
          disablePictureInPicture
          playsInline
        />
      ) : (
        <button
          aria-label="Play product video"
          className="
            w-14 h-14
            border border-white/60
            bg-white/10
            flex items-center justify-center
            hover:bg-white/20
            transition
          "
        >
          <svg
            className="w-6 h-6 text-white ml-1"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   SECTION COMPONENTS
   Each section is now a standalone, reusable component sized by its own
   content (no viewport-height math, no fragile centering). Bump the
   `size` prop to scale a section up or down without touching layout logic.
═══════════════════════════════════════════════════════════════════════ */

/**
 * VideoGridSection
 * Video on one side, a 2×2 image grid on the other.
 * Mobile: grid stacks ABOVE the video. Desktop: video LEFT, grid RIGHT.
 * Fills the viewport height exactly (deterministic h, not min-h+justify-center)
 * so it's the ONLY thing visible on load — scrolling reveals section 2.
 */
function VideoGridSection({ images, videoSrc, size = "lg" }) {
  // Controls overall scale of the whole block (video + grid together).
  // Tiles are aspect-square, so column width always drives tile height.
  const sizes = {
    md: { maxW: "lg:max-w-[900px]", gap: "[--grid-gap:1.25rem]" },
    lg: { maxW: "lg:max-w-[1140px]", gap: "[--grid-gap:1.5rem]" },
    xl: { maxW: "lg:max-w-none", gap: "[--grid-gap:1.75rem]" },
  };
  const { maxW, gap } = sizes[size] ?? sizes.lg;

  return (
    <section
      className={`
        ${gap} ${maxW} lg:mx-auto w-full
        h-[calc(100vh-8rem)]
        md:h-[calc(100vh-12rem)]
        flex flex-col
        overflow-hidden
      `}
    >
      <div className="flex flex-col lg:flex-row gap-5 lg:gap-10 items-stretch flex-1 min-h-0">
        {/* Image grid — full width on mobile (above video), 42% on desktop */}
        <div
          className="
            lg:w-[42%]
            w-full
            grid grid-cols-2
            gap-4 sm:gap-5 lg:gap-[var(--grid-gap)]
            lg:order-2
            auto-rows-fr
          "
        >
          {images.map((img, i) => (
            <ImageTile key={i} img={img} />
          ))}
        </div>

        {/* Video — full width on mobile (below grid), 58% on desktop.
            items-stretch on the parent row makes this match the grid's
            natural height automatically. */}
        <div className="lg:w-[58%] w-full lg:order-1 min-h-0">
          <VideoPlayer videoSrc={videoSrc} className="w-full h-full" />
        </div>
      </div>
    </section>
  );
}

/**
 * RowGridSection
 * Desktop: 4-image row, video strip below.
 * Mobile: video first, then a horizontally-scrollable filmstrip of larger
 * images — visually distinct from Section 1's even 2×2 grid.
 */
function RowGridSection({ images, videoSrc, size = "lg" }) {
  const sizes = {
    md: {
      tileHeight: "h-[160px] sm:h-[190px] lg:h-[220px]",
      videoHeight: "min-h-[220px] sm:min-h-[280px] lg:min-h-[340px]",
    },
    lg: {
      tileHeight: "h-[180px] sm:h-[220px] lg:h-[260px]",
      videoHeight: "min-h-[260px] sm:min-h-[340px] lg:min-h-[440px]",
    },
    xl: {
      tileHeight: "h-[200px] sm:h-[250px] lg:h-[300px]",
      videoHeight: "min-h-[300px] sm:min-h-[400px] lg:min-h-[520px]",
    },
  };
  const { tileHeight, videoHeight } = sizes[size] ?? sizes.lg;

  return (
    <section>
      {/* MOBILE/TABLET (< lg): video first, then a horizontally-scrollable
          filmstrip of images below it — visually distinct from Section 1's
          even 2×2 grid, instead of just a shrunk copy of the desktop layout. */}
      <div className="flex flex-col gap-4 lg:hidden">
        <VideoPlayer
          videoSrc={videoSrc}
          className={`w-full aspect-[16/10] ${videoHeight}`}
        />
        <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
          {images.map((img, i) => (
            <div
              key={i}
              className="shrink-0 w-[68%] sm:w-[42%] aspect-square snap-start"
            >
              <ImageTile img={img} />
            </div>
          ))}
        </div>
      </div>

      {/* DESKTOP (lg+): 4-image row, video strip below */}
      <div className="hidden lg:flex flex-col gap-6">
        <div className="grid grid-cols-4 gap-4">
          {images.map((img, i) => (
            <div key={i} className={tileHeight}>
              <ImageTile img={img} />
            </div>
          ))}
        </div>
        <VideoPlayer
          videoSrc={videoSrc}
          className={`w-full aspect-[21/9] ${videoHeight}`}
        />
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   PAGE
═══════════════════════════════════════════════════════════════════════ */

export default function ClassicEComVisuals({
  videoSrc = "https://drive.google.com/file/d/1LZSD2xmhrvFbRs4xDnipktbywr3lyHYs/view?usp=sharing",
  videoSrc2 = "https://drive.google.com/file/d/1LZSD2xmhrvFbRs4xDnipktbywr3lyHYs/view?usp=sharing",
  title = "Classic E-Commerce Visuals",
  eyebrow = "Product Showcase",
}) {
  return (
    <ServicePageLayout title={title} currentPage="/classic">
      <div className="flex flex-col gap-20 md:gap-28">
        <VideoGridSection images={images} videoSrc={videoSrc} size="xl" />
        <RowGridSection images={images2} videoSrc={videoSrc2} size="xl" />
      </div>
    </ServicePageLayout>
  );
}
