/**
 * FogHoverOverlay.jsx
 * -------------------------------------------------------------------------
 * Vanta FOG has no hover hooks of its own — its shader runs on a fixed
 * uniform set and doesn't know where the cursor is beyond the built-in
 * `mouseControls` parallax (which is subtle and not really "visible").
 * This overlay bolts a real, visible hover reaction on top of it:
 *
 *   "glow"       — soft light halo follows the cursor
 *   "swirl"      — fog appears to part/swirl away from the cursor
 *   "turbulence" — the fog itself speeds up / gets more turbulent near
 *                  the cursor (reports hover strength up via
 *                  onHoverStrengthChange so the caller can actually push
 *                  it into Vanta's own `speed` uniform — see
 *                  VantaBeatFogBackground.jsx)
 *   "colorBleed" — the beat's highlight color bleeds in around the cursor
 *   "none"       — renders nothing (default — opt-in per instance)
 *
 * It's a transparent <canvas> painted with plain 2D canvas API, stacked
 * directly on top of the Vanta container it's paired with. Pointer
 * events pass through (pointerEvents: none) — this is purely visual.
 *
 * USAGE (standalone, e.g. on VantaFogBackground on any page):
 *
 *   <div style={{ position: "relative" }}>
 *     <VantaFogBackground options={fogOptions} />
 *     <FogHoverOverlay effect="glow" color="#cfb05c" />
 *   </div>
 *
 * `effect` is the prop that controls "which particular element gets
 * which reaction" — pass a different value per instance/per beat.
 * -------------------------------------------------------------------------
 */

import { useEffect, useRef } from "react";

const EFFECT_TYPES = ["none", "glow", "swirl", "turbulence", "colorBleed"];

export default function FogHoverOverlay({
  effect = "none",
  color = "#cfb05c",
  intensity = 1,
  radius = 260,
  zIndex = 2,
  active = true,
  onHoverStrengthChange,
}) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    pointer: { x: -9999, y: -9999 },
    targetStrength: 0,
    strength: 0,
    angle: 0,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !active || effect === "none" || !EFFECT_TYPES.includes(effect)) {
      return undefined;
    }
    const ctx = canvas.getContext("2d");
    let raf = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = "100vw";
      canvas.style.height = "100vh";
    }
    resize();
    window.addEventListener("resize", resize);

    function onPointerMove(e) {
      stateRef.current.pointer = { x: e.clientX, y: e.clientY };
      stateRef.current.targetStrength = 1;
    }
    function onPointerLeave() {
      stateRef.current.targetStrength = 0;
    }
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerleave", onPointerLeave);
    window.addEventListener("blur", onPointerLeave);

    function drawGlow(s) {
      const { x, y } = stateRef.current.pointer;
      const r = radius * (0.85 + 0.15 * s);
      const grad = ctx.createRadialGradient(x * dpr, y * dpr, 0, x * dpr, y * dpr, r * dpr);
      grad.addColorStop(0, hexToRgba(color, 0.35 * intensity * s));
      grad.addColorStop(0.5, hexToRgba(color, 0.12 * intensity * s));
      grad.addColorStop(1, hexToRgba(color, 0));
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    function drawColorBleed(s) {
      const { x, y } = stateRef.current.pointer;
      const r = radius * 1.6 * (0.8 + 0.2 * s);
      const grad = ctx.createRadialGradient(x * dpr, y * dpr, 0, x * dpr, y * dpr, r * dpr);
      grad.addColorStop(0, hexToRgba(color, 0.22 * intensity * s));
      grad.addColorStop(0.6, hexToRgba(color, 0.08 * intensity * s));
      grad.addColorStop(1, hexToRgba(color, 0));
      ctx.globalCompositeOperation = "overlay";
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.globalCompositeOperation = "source-over";
    }

    function drawSwirl(s, dt) {
      const { x, y } = stateRef.current.pointer;
      stateRef.current.angle += dt * (0.6 + 1.4 * s);
      const arms = 5;
      for (let i = 0; i < arms; i++) {
        const a = stateRef.current.angle + (i / arms) * Math.PI * 2;
        const r1 = radius * 0.15;
        const r2 = radius * (0.9 + 0.1 * s);
        const x1 = x + Math.cos(a) * r1;
        const y1 = y + Math.sin(a) * r1;
        const x2 = x + Math.cos(a + 0.9) * r2;
        const y2 = y + Math.sin(a + 0.9) * r2;
        const grad = ctx.createLinearGradient(x1 * dpr, y1 * dpr, x2 * dpr, y2 * dpr);
        grad.addColorStop(0, hexToRgba(color, 0.22 * intensity * s));
        grad.addColorStop(1, hexToRgba(color, 0));
        ctx.strokeStyle = grad;
        ctx.lineWidth = 40 * dpr * (0.5 + 0.5 * s);
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x1 * dpr, y1 * dpr);
        ctx.quadraticCurveTo(
          (x + Math.cos(a + 0.45) * r2 * 0.6) * dpr,
          (y + Math.sin(a + 0.45) * r2 * 0.6) * dpr,
          x2 * dpr,
          y2 * dpr,
        );
        ctx.stroke();
      }
    }

    function drawTurbulence(s) {
      // Turbulence's main effect is Vanta's own speed uniform (reported
      // via onHoverStrengthChange below) — this overlay just adds a
      // faint agitated shimmer ring so the hover has a visible edge too.
      const { x, y } = stateRef.current.pointer;
      const rings = 3;
      for (let i = 0; i < rings; i++) {
        const r = radius * (0.3 + i * 0.25) * (0.9 + 0.1 * Math.sin(stateRef.current.angle * 3 + i));
        ctx.strokeStyle = hexToRgba(color, (0.1 - i * 0.02) * intensity * s);
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.arc(x * dpr, y * dpr, r * dpr, 0, Math.PI * 2);
        ctx.stroke();
      }
      stateRef.current.angle += 0.05;
    }

    let last = performance.now();
    function tick(now) {
      raf = requestAnimationFrame(tick);
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;

      // Smoothly ease hover strength in/out so the effect never pops.
      stateRef.current.strength +=
        (stateRef.current.targetStrength - stateRef.current.strength) * Math.min(dt * 6, 1);
      const s = stateRef.current.strength;
      onHoverStrengthChange?.(s);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (s < 0.002) return;

      if (effect === "glow") drawGlow(s);
      else if (effect === "colorBleed") drawColorBleed(s);
      else if (effect === "swirl") drawSwirl(s, dt);
      else if (effect === "turbulence") drawTurbulence(s);
    }
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerleave", onPointerLeave);
      window.removeEventListener("blur", onPointerLeave);
    };
  }, [effect, color, intensity, radius, active, onHoverStrengthChange]);

  if (!active || effect === "none") return null;

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        inset: 0,
        zIndex,
        width: "100vw",
        height: "100vh",
        pointerEvents: "none",
        mixBlendMode: "screen",
      }}
    />
  );
}

function hexToRgba(hex, alpha) {
  const clean = hex.replace("#", "");
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${Math.max(0, Math.min(1, alpha))})`;
}
