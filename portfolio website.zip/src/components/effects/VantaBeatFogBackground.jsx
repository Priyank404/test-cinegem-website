/**
 * VantaBeatFogBackground.jsx
 * -------------------------------------------------------------------------
 * Two stacked Vanta FOG canvases, crossfaded by opacity, driven by
 * RingHero's onBeatBlendUpdate weight — one instance per beat via
 * `beatOptions` (index 0 = Beat 1, index 1 = Beat 2, etc).
 *
 * Cursor interaction: NOT a drawn-on overlay. Both live effect instances
 * are patched (see vantaFogLoader.js -> patchFogEffectShader) so the
 * fog's own noise field genuinely parts/shifts away from the cursor in
 * the fragment shader itself — real fog displacement, matching what you
 * see everywhere else on screen, rather than a separate glow/swirl
 * layer drawn on top of it.
 *
 * HeroPage2.jsx usage:
 *
 *   import VantaBeatFogBackground from "@/components/effects/VantaBeatFogBackground";
 *   import { BEAT_FOG_PRESETS } from "@/components/effects/beatFogPresets";
 *
 *   const vantaBeatRef = useRef(null);
 *   // ...inside the same onBeatBlendUpdate callback RingHero already
 *   // calls, also call:
 *   vantaBeatRef.current?.setBlend({ fromIndex, toIndex, weight });
 *
 *   <VantaBeatFogBackground ref={vantaBeatRef} beatOptions={BEAT_FOG_PRESETS} zIndex={1} />
 *
 * NOTE ON COST: this runs up to two live Vanta/THREE WebGL contexts at
 * once. Fine on desktop; consider dropping to a single non-crossfaded
 * VantaFogBackground on low-end/mobile if you see jank.
 * -------------------------------------------------------------------------
 */

import { useEffect, useRef, useImperativeHandle, forwardRef } from "react";
import * as THREE from "three";
import { getFogConstructor, patchFogEffectShader } from "./vantaFogLoader";
import { DEFAULT_FOG_OPTIONS, normalizeFogOptions } from "./VantaFogBackground";

// How far the fog visibly pushes away from the cursor, and how far that
// push reaches before fading out. Same units patchFogEffectShader takes
// (see its own doc comment) — tune these two numbers to taste, they
// apply globally across every beat.
const MOUSE_REPULSION_STRENGTH = 0.9;
const MOUSE_REPULSION_RADIUS = 0.55;

const VantaBeatFogBackground = forwardRef(function VantaBeatFogBackground(
  { beatOptions = [], zIndex = 1 },
  ref,
) {
  const fromContainerRef = useRef(null);
  const toContainerRef = useRef(null);
  const fromEffectRef = useRef(null);
  const toEffectRef = useRef(null);
  const appliedRef = useRef({ from: -1, to: -1 });
  const blendRef = useRef({ fromIndex: 0, toIndex: 0, weight: 0 });
  const rafRef = useRef(0);

  // Same imperative shape as before — RingHero's callback doesn't need
  // to know which background layer(s) it's feeding, it just calls
  // setBlend() on whichever refs are mounted.
  useImperativeHandle(ref, () => ({
    setBlend(next) {
      blendRef.current = next;
    },
  }));

  useEffect(() => {
    const fromEl = fromContainerRef.current;
    const toEl = toContainerRef.current;
    if (!fromEl || !toEl) return;

    function optionsForBeat(index) {
      const safeIndex = Math.max(0, Math.min(index, beatOptions.length - 1));
      return {
        ...DEFAULT_FOG_OPTIONS,
        ...normalizeFogOptions(beatOptions[safeIndex] || {}),
      };
    }

    const FOG = getFogConstructor();

    function ensureEffect(effectRef, el, index) {
      const opts = optionsForBeat(index);
      if (!effectRef.current) {
        effectRef.current = FOG({ el, THREE, ...opts });
        patchFogEffectShader(effectRef.current, {
          strength: MOUSE_REPULSION_STRENGTH,
          radius: MOUSE_REPULSION_RADIUS,
        });
      } else {
        effectRef.current.setOptions(opts);
      }
    }

    function tick() {
      rafRef.current = requestAnimationFrame(tick);
      const { fromIndex, toIndex, weight } = blendRef.current;

      if (appliedRef.current.from !== fromIndex) {
        ensureEffect(fromEffectRef, fromEl, fromIndex);
        appliedRef.current.from = fromIndex;
      }
      if (appliedRef.current.to !== toIndex) {
        ensureEffect(toEffectRef, toEl, toIndex);
        appliedRef.current.to = toIndex;
      }

      // Same crossfade rule as before: "from" fades out as weight goes
      // 0->1, "to" fades in, and idle (fromIndex===toIndex) just shows
      // "from" at full opacity with no flicker.
      fromEl.style.opacity = String(1 - weight);
      toEl.style.opacity = String(fromIndex === toIndex ? 0 : weight);
    }
    tick();

    return () => {
      cancelAnimationFrame(rafRef.current);
      fromEffectRef.current?.destroy();
      toEffectRef.current?.destroy();
      fromEffectRef.current = null;
      toEffectRef.current = null;
      appliedRef.current = { from: -1, to: -1 };
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [beatOptions]);

  const layerStyle = {
    position: "fixed",
    inset: 0,
    zIndex,
    width: "100vw",
    height: "100vh",
    pointerEvents: "none",
  };

  return (
    <>
      <div ref={fromContainerRef} style={layerStyle} />
      <div ref={toContainerRef} style={layerStyle} />
    </>
  );
});

export default VantaBeatFogBackground;
