/**
 * vantaFogLoader.js
 * -------------------------------------------------------------------------
 * Vanta's dist files are UMD, and different bundlers (Vite/esbuild,
 * webpack, CRA) unwrap `import FOG from "vanta/dist/vanta.fog.min"`
 * differently — sometimes `FOG` IS the constructor, sometimes it's
 * `{ default: constructor }`, sometimes the constructor only ends up
 * attached to `window.VANTA.FOG` because the module's own `require("three")`
 * path didn't resolve the way it expected in your bundler.
 *
 * This loader tries every shape so `getFogConstructor()` always returns a
 * callable function (or throws a clear error instead of a cryptic
 * "FOG is not a function").
 * -------------------------------------------------------------------------
 */

import * as THREE from "three";
import * as VantaFogModule from "vanta/dist/vanta.fog.min";

// Some Vanta builds check for a global THREE instead of only using the
// one passed into the options object — cheap insurance, doesn't hurt.
if (typeof window !== "undefined" && !window.THREE) {
  window.THREE = THREE;
}

export function getFogConstructor() {
  const candidates = [
    VantaFogModule?.default,
    VantaFogModule,
    typeof window !== "undefined" ? window.VANTA?.FOG : undefined,
  ];

  for (const candidate of candidates) {
    if (typeof candidate === "function") return candidate;
  }

  throw new Error(
    "[vantaFogLoader] Could not resolve Vanta's FOG constructor from " +
      "'vanta/dist/vanta.fog.min'. Make sure `vanta` is installed " +
      "(npm install vanta) and that `three` is available as a peer " +
      'dependency. If you\'re on Vite, try adding "vanta" to ' +
      "optimizeDeps.include in vite.config.js.",
  );
}

/**
 * patchFogEffectShader
 * -------------------------------------------------------------------------
 * Vanta FOG already tracks the live cursor position every frame and
 * uploads it to a real shader uniform (`iMouse`, in canvas-pixel space) —
 * but the shipped fragment shader declares that uniform and never reads
 * it anywhere in main(). So out of the box, nothing about the fog's
 * actual noise field reacts to the cursor at all; only Vanta's separate
 * `mouseControls` camera-parallax option does anything, and that's just
 * a subtle whole-scene tilt, not the fog itself moving.
 *
 * This swaps in a small, minimally-invasive edit to that same shader:
 * before doing the FBM lookup, it computes distance from the fragment
 * to the cursor (in the same `st` space used for noise sampling) and
 * pushes the sample coordinate radially away from the cursor, falling
 * off with distance. The result is the noise field itself visibly
 * parting/swirling away from wherever the cursor is — real shader-level
 * displacement, not a drawn-on overlay — while everywhere else on
 * screen renders exactly as before.
 *
 * Call this once, right after the Vanta FOG() constructor returns the
 * effect instance. Safe to call multiple times (idempotent — checks a
 * flag before re-patching).
 *
 * Set FOG_DEBUG (exported above) to true to get console confirmation
 * that the patch applied and that live cursor data is reaching the
 * effect's iMouse uniform every frame.
 *
 * @param {object} effect  The instance returned by FOG({ el, THREE, ...opts }).
 * @param {object} [tuning]
 * @param {number} [tuning.strength=0.9]  How far (in shader `st` units,
 *   same scale as `zoom`) the noise sample point shifts away from the
 *   cursor at zero distance. Higher = fog visibly "opens a hole" wider.
 * @param {number} [tuning.radius=0.55]   Falloff radius in normalized
 *   screen-space (0 = a point, ~1 = full viewport). Larger = the push
 *   effect reaches further from the cursor before fading to nothing.
 */
// Flip to true to see console logs confirming (a) the shader patch
// actually applied to a given Vanta FOG effect instance, and (b) the
// live iMouse uniform is updating as you move the cursor (proof the
// signal is reaching the fog, independent of whether the visual push
// is strong enough to notice). Safe to leave on during development —
// logs are throttled, not per-frame-spam.
export const FOG_DEBUG = true;

function fogLog(...args) {
  if (FOG_DEBUG) {
    // eslint-disable-next-line no-console
    console.log("[fog debug]", ...args);
  }
}

export function patchFogEffectShader(effect, tuning = {}) {
  if (!effect || !effect.material) {
    fogLog("patch skipped — no effect or no material yet", { effect });
    return;
  }
  if (effect._mouseRepulsionPatched) {
    fogLog("patch skipped — this effect instance is already patched");
    return;
  }

  const strength = tuning.strength ?? 0.9;
  const radius = tuning.radius ?? 0.55;

  const original = effect.material.fragmentShader;
  if (!original || !original.includes("void main() {")) {
    fogLog("patch FAILED — 'void main() {' anchor not found in shader source");
    return;
  }
  if (!original.includes("st *= zoom;")) {
    fogLog("patch FAILED — 'st *= zoom;' anchor not found in shader source");
    return;
  }

  // Insert the cursor-repulsion displacement right after `st` (the
  // noise-sampling coordinate) is computed and zoomed, so every FBM
  // octave downstream sees the pushed-away coordinate — the "hole"
  // reads as part of the fog's own turbulence, not a separate layer.
  const withMouseVars = original.replace(
    "void main() {",
    `void main() {\n` +
      `  // --- cursor repulsion patch (patchFogEffectShader) ---\n` +
      `  vec2 uv = gl_FragCoord.xy / iResolution.xy;\n` +
      `  vec2 mouseUv = iMouse / iResolution.xy;\n`,
  );

  const withRepulsion = withMouseVars.replace(
    "st *= zoom;",
    `st *= zoom;\n` +
      `  {\n` +
      `    vec2 toFrag = uv - mouseUv;\n` +
      `    toFrag.x *= iResolution.x / iResolution.y;\n` +
      `    float d = length(toFrag);\n` +
      `    float falloff = smoothstep(${radius.toFixed(3)}, 0.0, d);\n` +
      `    vec2 pushDir = d > 0.0001 ? normalize(toFrag) : vec2(0.0);\n` +
      `    st += pushDir * falloff * ${strength.toFixed(3)};\n` +
      `  }\n`,
  );

  if (withRepulsion === original) {
    fogLog("patch FAILED — string replace produced no change (unexpected)");
    return;
  }

  // IMPORTANT: mutating an existing THREE.ShaderMaterial's
  // .fragmentShader string and setting .needsUpdate = true does NOT
  // recompile the GLSL program — Material.needsUpdate only covers
  // texture/uniform-type changes, not shader source. The GPU program
  // Vanta already compiled and linked keeps running unchanged, so the
  // patch silently has zero visible effect no matter how correct the
  // string edit is. The reliable fix is to build a brand-new
  // ShaderMaterial from the patched source and swap it onto the actual
  // mesh, forcing Three.js to compile a fresh program next frame.
  const quadMesh = effect.scene?.children?.find(
    (child) => child.isMesh && child.material === effect.material,
  );
  if (!quadMesh) {
    fogLog(
      "patch FAILED — could not find the fullscreen quad mesh in effect.scene.children",
      { sceneChildren: effect.scene?.children },
    );
    return;
  }

  const patchedMaterial = effect.material.clone();
  patchedMaterial.fragmentShader = withRepulsion;
  patchedMaterial.needsUpdate = true;

  quadMesh.material = patchedMaterial;
  effect.material = patchedMaterial;
  effect._mouseRepulsionPatched = true;

  fogLog("patch APPLIED successfully", { strength, radius, quadMesh });

  if (FOG_DEBUG) {
    startFogDebugLogging(effect);
  }
}

/**
 * startFogDebugLogging
 * -------------------------------------------------------------------------
 * Throttled per-frame confirmation that live cursor data is actually
 * reaching this fog effect's iMouse uniform — proof the signal path
 * works end-to-end, independent of whether the visual push is subtle.
 * Logs at most once every ~500ms per effect instance. Call directly if
 * you want logging without going through patchFogEffectShader (e.g. to
 * debug mouseControls/iMouse on an unpatched effect too).
 * -------------------------------------------------------------------------
 */
export function startFogDebugLogging(effect) {
  if (!effect || !effect.uniforms?.iMouse || effect._fogDebugLogging) return;
  effect._fogDebugLogging = true;

  let lastLogTime = 0;
  const tick = () => {
    if (effect._fogDebugLoggingStopped) return;
    const now = performance.now();
    if (now - lastLogTime > 500) {
      lastLogTime = now;
      const { x, y } = effect.uniforms.iMouse.value;
      fogLog("iMouse uniform live value:", {
        x: x.toFixed(1),
        y: y.toFixed(1),
      });
    }
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
