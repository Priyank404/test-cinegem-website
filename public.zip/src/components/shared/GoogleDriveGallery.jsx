// ============================================================
// GoogleDriveGallery.jsx
// Drop this file into your React project's src/components/ folder
// ============================================================

import { useState, useEffect } from "react";

// ─────────────────────────────────────────────
// CONFIGURATION — edit this section only
// ─────────────────────────────────────────────
const API_KEY = "AIzaSyDHKGn32bEnAixAW4vvzcenwyv0j2h7vWk"; // From Google Cloud Console

// Map each page/route to its Drive Folder ID
export const DRIVE_FOLDERS = {
  "still-image":    "189ojwhpp08ugXI4XJ5bMgK-3g5UjiiNy",
  // "creative-image": "YOUR_CREATIVE_IMAGE_FOLDER_ID",
  // "page-3":         "YOUR_PAGE_3_FOLDER_ID",
  // "page-4":         "YOUR_PAGE_4_FOLDER_ID",
  // "page-5":         "YOUR_PAGE_5_FOLDER_ID",
};
// ─────────────────────────────────────────────


// ─────────────────────────────────────────────
// Custom Hook: useDriveImages
// Usage: const { images, loading, error } = useDriveImages("still-image");
// ─────────────────────────────────────────────
export function useDriveImages(pageKey) {
  const [images, setImages]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const folderId = DRIVE_FOLDERS[pageKey];

  useEffect(() => {
    if (!folderId) {
      setError(`No folder configured for page: "${pageKey}"`);
      setLoading(false);
      return;
    }

    const fetchImages = async () => {
      setLoading(true);
      setError(null);
      try {
        const query    = encodeURIComponent(`'${folderId}' in parents and mimeType contains 'image/' and trashed = false`);
        const fields   = encodeURIComponent("files(id,name,mimeType,createdTime)");
        const orderBy  = encodeURIComponent("createdTime desc");
        const url      = `https://www.googleapis.com/drive/v3/files?q=${query}&key=${API_KEY}&fields=${fields}&orderBy=${orderBy}&pageSize=100`;

        const res  = await fetch(url);
        if (!res.ok) throw new Error(`Drive API error: ${res.status} ${res.statusText}`);
        const data = await res.json();

        if (data.error) throw new Error(data.error.message);

        // Build thumbnail + full-size URLs
        const mapped = (data.files || []).map((file) => ({
          id:        file.id,
          name:      file.name,
          thumb:     `https://drive.google.com/thumbnail?id=${file.id}&sz=w600`,
          full:      `https://drive.google.com/thumbnail?id=${file.id}&sz=w1600`,
          driveUrl:  `https://drive.google.com/file/d/${file.id}/view`,
          createdAt: file.createdTime,
        }));

        setImages(mapped);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchImages();
  }, [folderId, pageKey]);

  return { images, loading, error };
}


// ─────────────────────────────────────────────
// Lightbox Component
// ─────────────────────────────────────────────
function Lightbox({ image, onClose, onPrev, onNext }) {
  useEffect(() => {
    const handler = (e) => {
      if (e.key === "Escape")     onClose();
      if (e.key === "ArrowRight") onNext();
      if (e.key === "ArrowLeft")  onPrev();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose, onPrev, onNext]);

  return (
    <div style={styles.overlay} onClick={onClose}>
      {/* Prevent click on image from closing */}
      <div style={styles.lightboxContent} onClick={(e) => e.stopPropagation()}>
        <button style={styles.closeBtn} onClick={onClose} aria-label="Close">✕</button>
        <button style={{ ...styles.navBtn, left: 12 }} onClick={onPrev} aria-label="Previous">‹</button>
        <img src={image.full} alt={image.name} style={styles.lightboxImg} />
        <button style={{ ...styles.navBtn, right: 12 }} onClick={onNext} aria-label="Next">›</button>
        <p style={styles.caption}>{image.name.replace(/\.[^/.]+$/, "")}</p>
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────
// Main Gallery Component
// ─────────────────────────────────────────────
export default function DriveGallery({ pageKey, title, columns = 3 }) {
  const { images, loading, error } = useDriveImages(pageKey);
  const [activeIndex, setActiveIndex] = useState(null);

  const openLightbox  = (i) => setActiveIndex(i);
  const closeLightbox = ()  => setActiveIndex(null);
  const showPrev      = ()  => setActiveIndex((i) => (i - 1 + images.length) % images.length);
  const showNext      = ()  => setActiveIndex((i) => (i + 1) % images.length);

  // ── Loading state ──
  if (loading) {
    return (
      <div style={styles.center}>
        <div style={styles.spinner} />
        <p style={styles.statusText}>Loading images…</p>
      </div>
    );
  }

  // ── Error state ──
  if (error) {
    return (
      <div style={styles.center}>
        <p style={styles.errorText}>⚠ {error}</p>
        <p style={styles.hintText}>
          Check your API key and make sure the folder is shared as "Anyone with the link".
        </p>
      </div>
    );
  }

  // ── Empty state ──
  if (images.length === 0) {
    return (
      <div style={styles.center}>
        <p style={styles.statusText}>No images found in this folder.</p>
        <p style={styles.hintText}>Upload images to your Google Drive folder — they'll appear here automatically.</p>
      </div>
    );
  }

  return (
    <section style={styles.section}>
      {title && <h2 style={styles.heading}>{title}</h2>}

      <p style={styles.countBadge}>{images.length} image{images.length !== 1 ? "s" : ""}</p>

      {/* Responsive grid */}
      <div
        style={{
          ...styles.grid,
          gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
        }}
      >
        {images.map((img, i) => (
          <div
            key={img.id}
            style={styles.card}
            onClick={() => openLightbox(i)}
            role="button"
            tabIndex={0}
            aria-label={`Open ${img.name}`}
            onKeyDown={(e) => e.key === "Enter" && openLightbox(i)}
          >
            <img
              src={img.thumb}
              alt={img.name}
              loading="lazy"
              style={styles.thumb}
              onError={(e) => { e.target.style.opacity = 0.3; }}
            />
            <div style={styles.cardOverlay}>
              <span style={styles.cardName}>{img.name.replace(/\.[^/.]+$/, "")}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox */}
      {activeIndex !== null && (
        <Lightbox
          image={images[activeIndex]}
          onClose={closeLightbox}
          onPrev={showPrev}
          onNext={showNext}
        />
      )}
    </section>
  );
}


// ─────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────
const styles = {
  section: {
    padding: "2rem 1.5rem",
    maxWidth: 1200,
    margin: "0 auto",
    fontFamily: "system-ui, sans-serif",
  },
  heading: {
    fontSize: "clamp(1.4rem, 3vw, 2rem)",
    fontWeight: 700,
    marginBottom: "0.25rem",
    color: "#111",
  },
  countBadge: {
    fontSize: "0.85rem",
    color: "#888",
    marginBottom: "1.5rem",
  },
  grid: {
    display: "grid",
    gap: "1rem",
  },
  card: {
    position: "relative",
    aspectRatio: "1 / 1",
    overflow: "hidden",
    borderRadius: 8,
    cursor: "pointer",
    background: "#f0f0f0",
    transition: "transform 0.2s, box-shadow 0.2s",
  },
  thumb: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    display: "block",
    transition: "transform 0.3s",
  },
  cardOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    background: "linear-gradient(transparent, rgba(0,0,0,0.6))",
    padding: "1.5rem 0.75rem 0.6rem",
    opacity: 0,
    transition: "opacity 0.2s",
  },
  cardName: {
    color: "#fff",
    fontSize: "0.8rem",
    fontWeight: 500,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    display: "block",
  },
  // Lightbox
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.92)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9999,
  },
  lightboxContent: {
    position: "relative",
    maxWidth: "90vw",
    maxHeight: "90vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  lightboxImg: {
    maxWidth: "85vw",
    maxHeight: "80vh",
    objectFit: "contain",
    borderRadius: 6,
  },
  caption: {
    color: "#ccc",
    fontSize: "0.85rem",
    marginTop: "0.75rem",
  },
  closeBtn: {
    position: "absolute",
    top: -36,
    right: 0,
    background: "none",
    border: "none",
    color: "#fff",
    fontSize: "1.3rem",
    cursor: "pointer",
    padding: "4px 8px",
  },
  navBtn: {
    position: "absolute",
    top: "50%",
    transform: "translateY(-50%)",
    background: "rgba(255,255,255,0.15)",
    border: "none",
    color: "#fff",
    fontSize: "2rem",
    cursor: "pointer",
    borderRadius: 6,
    padding: "4px 12px",
    lineHeight: 1,
  },
  // States
  center: {
    textAlign: "center",
    padding: "4rem 2rem",
    fontFamily: "system-ui, sans-serif",
  },
  statusText: {
    color: "#555",
    fontSize: "1rem",
  },
  errorText: {
    color: "#c0392b",
    fontWeight: 600,
    fontSize: "1rem",
  },
  hintText: {
    color: "#888",
    fontSize: "0.85rem",
    marginTop: "0.5rem",
    maxWidth: 400,
    margin: "0.5rem auto 0",
  },
  spinner: {
    width: 36,
    height: 36,
    border: "3px solid #ddd",
    borderTop: "3px solid #555",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
    margin: "0 auto 1rem",
  },
};
