// CreativeVisualsPage.jsx
//
// "Creative Visuals" service page.
//   1. Classic nav + cinematic hero (same shell as ClassicEComVisuals).
//   2. Below the hero: a true masonry grid of jewellery photos & videos.
//      Fixed-width columns, but every tile keeps its own natural height —
//      the box IS the image's real proportions, nothing is cropped to fit
//      a predetermined shape. A small square photo gets a small box; a
//      long portrait shot gets a tall box; a wide shot gets a short,
//      wide box. This matches the reference collage (masonry columns,
//      each item its native aspect ratio) rather than a fixed grid of
//      pre-shaped cells.
import { useState, useEffect, useRef, useMemo } from "react";
import { gsap } from "gsap";
import { ServicePageLayout } from "@/components/shared/ServicePageLayout";
import HeroSection from "@/components/sections/HeroSection";
import { LightboxModal } from "@/components/shared/LightboxModal";
import { useLightbox } from "@/hooks/useLightbox";
import Silk from "@/components/three/Silk";

// Tracks the true, scrollbar-safe viewport width (document.documentElement
// .clientWidth excludes the scrollbar; 100vw does not — that mismatch is
// what causes a full-bleed section to overshoot the visible area on one
// side, leaving a stray gap of background color showing on the other side
// once the scrollbar is accounted for). Falls back to 0 during SSR/first
// paint, before which the full-bleed sections simply render at their
// natural width until the effect runs.
function useViewportWidth() {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    const update = () => setWidth(document.documentElement.clientWidth);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);
  return width;
}

/* ═══════════════════════════════════════════════════════════════════════
   DATA — creative jewellery photography + video
═══════════════════════════════════════════════════════════════════════ */

// Just drop in { type, src, alt } for a new photo or video — no shape
// tagging needed. The masonry grid below renders every tile at its own
// real width/height ratio, so the box always matches the file itself.
const mediaItems = [
  { type: "image", src: "/Creative visuals/4 Ring Banner T4 HQ_.jpg", alt: "Enamel marquise band ring, hero angle" },
  { type: "video", src: "/Creative visuals/360 Turntable black.mp4", alt: "Enamel marquise band ring, hero angle" },
  { type: "video", src: "/Creative visuals/A6-R3-HQ.mp4", alt: "Enamel marquise band ring, hero angle" },
  { type: "image", src: "/Creative visuals/RG01-Y-B-V2.png", alt: "Cinegem signature jewellery still" },
  { type: "video", src: "/Creative visuals/B4 ANimated.mp4", alt: "Enamel marquise band ring, hero angle" },
  { type: "image", src: "/Creative visuals/Beauty.png", alt: "Enamel marquise band ring, hero angle" },
  { type: "video", src: "/Creative visuals/E commerce 1 with Music.mp4", alt: "Enamel marquise band ring, hero angle" },
  { type: "image", src: "/Creative visuals/Earring 1 YG BlackBG V0000.png", alt: "Enamel marquise band ring, hero angle" },
  { type: "image", src: "/Creative visuals/Earring 1 YG BlackBG V0001.png", alt: "Two-tone gold ring, geometric pavé setting" },
  { type: "image", src: "/Creative visuals/SR-B-9-Y-V1.png", alt: "Gold pendant, front view" },
  { type: "video", src: "/Creative visuals/Multishot Brown.mp4", alt: "Gold chain necklace, editorial still" },

  { type: "video", src: "/Creative visuals/M-Video.mp4", alt: "Pendant detail, front view" },
  { type: "image", src: "/Creative visuals/NB-1 LO R.png", alt: "Hidden-halo ring, 360° turntable" },
  { type: "image", src: "/Creative visuals/NP-1-YG-LS2-V2.png", alt: "Rose gold pendant, macro" },

  { type: "image", src: "/Creative visuals/R1-L2-P1-SB-Y-V4.png", alt: "Diamond bracelet, editorial still" },
  { type: "image", src: "/Creative visuals/R4-L2-Y-V4.png", alt: "Creative CGI jewellery composition" },

  { type: "image", src: "/Creative visuals/RG01_Out2_0000.png", alt: "Ring detail, cinematic loop" },
  { type: "image", src: "/Creative visuals/RG01-Y-B-V1.png", alt: "Diamond stud earrings, editorial still" },
  { type: "image", src: "/Creative visuals/RG01-Y-B-V2.png", alt: "Cinegem signature jewellery still" },

  { type: "image", src: "/Creative visuals/RG01-Y-B-V3.png", alt: "Two-tone gold ring, front angle" },
  { type: "image", src: "/Creative visuals/RG01-Y-B-V4.png", alt: "Diamond ring, editorial macro" },
  { type: "image", src: "/Creative visuals/Ring 2-Color BG-V1-R3.png", alt: "Diamond drop earrings on dark surface" },
  { type: "image", src: "/Creative visuals/Ring 2-Color BG-V1-R6.png", alt: "Sculptural gold ring, editorial still" },
  { type: "image", src: "/Creative visuals/ring.png", alt: "Emerald ring on marble" },
  { type: "image", src: "/Creative visuals/SR-B-9-Y-V1.png", alt: "Pearl necklace, editorial still" },

  { type: "image", src: "/Creative visuals/Screenshot 2023-07-15 183627.png", alt: "Gold necklace and earring set, display still" },
  { type: "image", src: "/Creative visuals/SR-B-9-Y-V1.png", alt: "Gold hoop earrings" },
  { type: "image", src: "/Creative visuals/SR-B-9-Y-V1.png", alt: "Vintage gold and gemstone ring" },

  { type: "image", src: "/Creative visuals/Screenshot 2023-12-20 080608.png", alt: "Layered gold necklaces" },
  { type: "image", src: "/Creative visuals/Screenshot 2023-12-20 080659.png", alt: "Gold chain bracelet, editorial still" },

  { type: "image", src: "/Creative visuals/Screenshot 2024-06-24 184639.png", alt: "Two-tone gold ring, side profile" },
  { type: "image", src: "/Creative visuals/Screenshot 2024-06-24 184713.png", alt: "Two-tone gold ring, angled profile" },
  { type: "image", src: "/Creative visuals/Screenshot 2024-06-24 184810.png", alt: "Round halo diamond ring, front view" },
  { type: "image", src: "/Creative visuals/Screenshot 2024-06-24 184847.png", alt: "Round halo diamond ring, tight macro crop" },
  { type: "image", src: "/Creative visuals/SR-B-9-Y-V1.png", alt: "Gold pendant with geometric diamond links, full length" },
  { type: "image", src: "/Creative visuals/RG01-Y-B-V1.png", alt: "Enamel marquise band ring, hero angle" },
  { type: "image", src: "/Creative visuals/R4-L2-Y-V4.png", alt: "Creative CGI jewellery composition" },
  { type: "video", src: "/Creative visuals/M-Video.mp4", alt: "Pendant detail, front view" },
];

/* ═══════════════════════════════════════════════════════════════════════
   ORBIT GRID — CSS multi-column masonry, same underlying mechanism as
   the story layout's video/image tiles: fixed-width columns, and each tile's own
   <img>/<video> sets its own height via h-auto, so the box IS the file's
   real aspect ratio. No fixed-size cells, no object-contain letterboxing,
   nothing to "fit" — there's no mismatch between box and image to begin
   with, so the awkward padding when a square-ish photo landed in a
   forced 1x1 cell (or a fixed-track grid computed the wrong span) simply
   can't happen anymore.
   Orbit stays visually distinct from the default Grid view via a larger,
   fewer-column layout (bigger tiles, more breathing room), images and
   videos shuffled together randomly (see shuffleWithOriginalIndex below)
   instead of rendering in data order, and GSAP animation adapted from
   the React Bits Masonry component:
     - load-in: fades/slides up from below with a blur-to-focus resolve,
       staggered across tiles (animateFrom="bottom" + blurToFocus)
     - continuous drift: once settled in, each tile gently floats in
       place on its own randomized loop, giving the grid an "in orbit"
       feel rather than sitting perfectly still
   Only the animation behavior is borrowed from that component; sizing
   stays driven by each file's real aspect ratio (not a fixed height
   prop) and clicking still opens the shared lightbox (not a new tab),
   since those are what make this grid correct for real jewellery
   photography/video in the first place.
═══════════════════════════════════════════════════════════════════════ */

function OrbitTile({ item, onOpen, staggerIndex }) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [inView, setInView] = useState(false);
  const videoRef = useRef(null);
  const wrapperRef = useRef(null);
  const hasAnimated = useRef(false);
  const floatTween = useRef(null);

  // Gate the entrance animation on scroll position, not just file-load
  // completion. Without this, tiles fire the instant their own image/
  // video finishes downloading — which, on a fast connection, can mean
  // tiles far below the fold animate in at the same moment as tiles at
  // the top, all at once, instead of resolving as the person actually
  // scrolls down to them. threshold: 0.15 + rootMargin gives the tile a
  // small head start so it's settled in by the time it's fully in view,
  // rather than animating mid-scroll.
  useEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect(); // only need to fire once per tile
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -5% 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Mobile browsers (data-saver mode, low-power mode) frequently ignore
  // the bare `autoPlay` attribute. preload="auto" makes sure a real frame
  // downloads and paints regardless of whether autoplay succeeds, and
  // explicitly calling play() (with a .catch to swallow the still-
  // possible rejection) is the standard workaround for browsers that need
  // a script-driven play call rather than just the attribute.
  useEffect(() => {
    if (item.type !== "video") return;
    const el = videoRef.current;
    if (!el) return;
    const tryPlay = () => {
      const playPromise = el.play();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(() => {
          /* Autoplay blocked — preload="auto" still gets a frame on
             screen, so the tile shows real content, just paused. */
        });
      }
    };
    tryPlay();
    el.addEventListener("canplay", tryPlay);
    return () => el.removeEventListener("canplay", tryPlay);
  }, [item.type, item.src]);

  // GSAP load-in: only once this tile's own media has loaded AND it has
  // scrolled into view (both loaded and inView must be true) does it
  // animate up from slightly below with a blur-to-focus resolve,
  // matching the reference Masonry component's animateFrom="bottom" +
  // blurToFocus look. Gating on inView is what makes tiles resolve as
  // you actually scroll to them, instead of every already-loaded tile on
  // the page (including ones far below the fold) firing together the
  // moment their file happens to finish downloading.
  // Runs once per tile (hasAnimated guards against firing again) and is
  // staggered by the tile's position so a row of tiles that all just
  // entered the viewport together still cascades in, rather than
  // snapping in as one block. Once the entrance settles, a continuous
  // drift kicks in (see below).
  useEffect(() => {
    if (!loaded || !inView || hasAnimated.current || !wrapperRef.current) return;
    hasAnimated.current = true;
    const el = wrapperRef.current;
    gsap.fromTo(
      el,
      { opacity: 0, y: 40, filter: "blur(10px)" },
      {
        opacity: 1,
        y: 0,
        filter: "blur(0px)",
        duration: 0.6,
        ease: "power3.out",
        delay: (staggerIndex % 6) * 0.06,
        onComplete: () => {
          // Continuous "in orbit" drift — a slow, gentle, never-quite-
          // repeating float. Each tile gets its own randomized amplitude,
          // duration, and horizontal offset (seeded off staggerIndex so
          // it's stable across re-renders) so the grid doesn't read as a
          // single mechanical wave, but as many independently-drifting
          // tiles. yoyo+repeat:-1 keeps it looping forever at low cost
          // since GSAP just reverses the same tween rather than re-timing.
          const seed = (staggerIndex * 37) % 100;
          const driftY = 6 + (seed % 6); // 6–11px vertical drift
          const driftX = ((seed % 5) - 2) * 1.6; // small, varied horizontal drift
          const duration = 3.2 + (seed % 9) * 0.22; // ~3.2–5.1s, varied per tile

          floatTween.current = gsap.to(el, {
            y: `+=${driftY}`,
            x: `+=${driftX}`,
            duration,
            ease: "sine.inOut",
            yoyo: true,
            repeat: -1,
          });
        },
      }
    );

    return () => {
      floatTween.current?.kill();
    };
  }, [loaded, inView, staggerIndex]);

  // If the file 404s or otherwise fails to load, collapse the tile
  // entirely instead of leaving a blank placeholder box in the column.
  if (failed) return null;

  return (
    <div
      ref={wrapperRef}
      className="relative w-full overflow-hidden bg-[#EDEAE3]"
      style={{ opacity: 0 }}
    >
      <button
        type="button"
        onClick={onOpen}
        aria-label={`Zoom in on ${item.alt}`}
        className="block w-full cursor-pointer focus:outline-none"
      >
        {item.type === "video" ? (
          <video
            ref={videoRef}
            src={item.src}
            className="block w-full h-auto"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            onLoadedData={() => setLoaded(true)}
            onError={() => setFailed(true)}
          />
        ) : (
          <img
            src={item.src}
            alt={item.alt}
            className="block w-full h-auto"
            loading="lazy"
            onLoad={() => setLoaded(true)}
            onError={() => setFailed(true)}
          />
        )}

        {item.type === "video" && (
          <span className="absolute top-3 right-3 font-[Manrope] text-[9px] tracking-[0.15em] font-semibold uppercase px-2.5 py-1 bg-[#121212]/70 text-[#FAF9F6] backdrop-blur-sm">
            Video
          </span>
        )}
      </button>
    </div>
  );
}

// Fisher-Yates shuffle. Keeps each item's ORIGINAL index attached (as
// __index) so the shuffled tile can still open the right slide in the
// shared lightbox, which navigates by position in the untouched
// `mediaItems` array, not the shuffled render order.
function shuffleWithOriginalIndex(items) {
  const withIndex = items.map((item, __index) => ({ item, __index }));
  for (let i = withIndex.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [withIndex[i], withIndex[j]] = [withIndex[j], withIndex[i]];
  }
  return withIndex;
}

function OrbitGrid({ items, onOpen }) {
  // Shuffled once per mount/items-change (useMemo), not on every re-render
  // — OrbitTile's own state updates (finishing load) would otherwise
  // re-run Math.random() each time and make tiles visibly jump to new
  // positions mid-load.
  const shuffled = useMemo(() => shuffleWithOriginalIndex(items), [items]);

  return (
    <>
      <style>{`
        .orbit-masonry {
          column-count: 2;
          column-gap: 0.75rem;
        }
        .orbit-masonry > * {
          break-inside: avoid;
          margin-bottom: 0.75rem;
        }
        @media (min-width: 640px) {
          .orbit-masonry { column-count: 2; column-gap: 1rem; }
          .orbit-masonry > * { margin-bottom: 1rem; }
        }
        @media (min-width: 1024px) {
          .orbit-masonry { column-count: 3; column-gap: 1.25rem; }
          .orbit-masonry > * { margin-bottom: 1.25rem; }
        }
        @media (min-width: 1536px) {
          .orbit-masonry { column-count: 4; column-gap: 1.5rem; }
          .orbit-masonry > * { margin-bottom: 1.5rem; }
        }
      `}</style>
      <div className="bg-transparent p-2 md:p-3">
        <div className="orbit-masonry">
          {shuffled.map(({ item, __index }, position) => (
            <OrbitTile
              key={__index}
              item={item}
              onOpen={() => onOpen(__index)}
              staggerIndex={position}
            />
          ))}
        </div>
      </div>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   PAGE
═══════════════════════════════════════════════════════════════════════ */

// Default view is the scroll-driven story sequence below (see
// ScrollStoryLayout). Orbit view uses OrbitGrid, a masonry mechanism with a larger,
// fewer-column layout: images and videos are shuffled together randomly
// instead of rendering in data order, each tile animates in with GSAP
// (fade/rise/blur-to-focus) as its media finishes loading, and hovering
// a tile scales it down slightly with a soft color-shift overlay.
/* ═══════════════════════════════════════════════════════════════════════
   SCROLL STORY LAYOUT — the full page sequence:
     1. Video (left, 50%) + 4 images in a 2x2 grid (right, 50%), no
        scroll effects — everything just sits in place.
     2. Same as 1, mirrored: large static video (left) + 4 fixed images
        (right).
     3. Full-width static video.
     4. Two long images side by side.
     5. Full-width video that drifts upward as you scroll past it.
═══════════════════════════════════════════════════════════════════════ */

// Section 1 layout: video on the left at 50% width, with the 4 images
// arranged in a 2x2 grid filling the other 50% on the right. The outer
// wrapper still breaks out to the full browser width edge-to-edge (same
// full-bleed technique used elsewhere on this page), but the two halves
// now sit side by side instead of the video stacking full-width on top.
function FullWidthVideoWithImagesBelow({ video, images, onOpen }) {
  const vw = useViewportWidth();
  return (
    <section
      className="relative w-auto bg-[#121212]"
      style={vw ? { marginLeft: `calc(50% - ${vw / 2}px)`, marginRight: `calc(50% - ${vw / 2}px)` } : undefined}
    >
      {/* Zero gap, zero padding: the video sits flush against the browser's
          left edge and the image grid sits flush against the right edge,
          with no seam of page background visible between or around them.
          bg-[#121212] on the section (matching the tile background used
          elsewhere) means even the split second before media paints, or
          any sub-pixel rounding gap between columns, reads as part of the
          artwork rather than as a stray light-colored strip. */}
      <div className="grid grid-cols-1 md:grid-cols-2">
        <div className="relative overflow-hidden h-[70vh] md:h-[140vh]">
          <video
            src={video.src}
            className="block w-full h-full object-contain"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
          />
        </div>
        <div className="grid grid-cols-2 grid-rows-2 h-[70vh] md:h-[140vh]">
          {images.slice(0, 4).map((img) => (
            <button
              key={img.src}
              type="button"
              onClick={() => onOpen(img.mediaIndex)}
              aria-label={`Zoom in on ${img.alt}`}
              className="relative block w-full h-full cursor-pointer focus:outline-none overflow-hidden"
            >
              <img src={img.src} alt={img.alt} className="block w-full h-full object-cover" loading="lazy" />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

// Static side-by-side layout (Section 2): a full-size video on one side
// and a fixed 2x2 grid of 4 images on the other. No scroll-driven
// effects — both the video and the images just sit in place. `reverse`
// flips which side the video is on.
//
// The outer wrapper breaks out of the page's max-width/padding container
// using the calc(50% - 50vw) full-bleed trick, so the video and image
// grid together stretch edge-to-edge of the browser window, rather than
// stopping at the page's normal content width.
function VideoWithImages({ video, images, onOpen, reverse, imagesWider }) {
  const vw = useViewportWidth();
  const videoWidthClass = imagesWider ? "md:w-[45%]" : "md:w-1/2";
  const imageWidthClass = imagesWider ? "md:w-[55%]" : "md:w-1/2";

  const videoCol = (
    <div className={`w-full ${videoWidthClass}`}>
      <div className="relative w-full overflow-hidden bg-[#EDEAE3]">
        <video
          src={video.src}
          className="block w-full h-[100vh] md:h-[125vh] object-cover"
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
        />
      </div>
    </div>
  );

  const imageCol = (
    <div className={`w-full ${imageWidthClass} grid grid-cols-2 gap-3 md:gap-4 content-start overflow-y-auto max-h-[100vh] md:max-h-[125vh]`}>
      {images.slice(0, 4).map((img) => (
        <button
          key={img.src}
          type="button"
          onClick={() => onOpen(img.mediaIndex)}
          aria-label={`Zoom in on ${img.alt}`}
          className="block w-full cursor-pointer focus:outline-none overflow-hidden bg-[#EDEAE3]"
        >
          <img src={img.src} alt={img.alt} className="block w-full h-auto" loading="lazy" />
        </button>
      ))}
    </div>
  );

  return (
    <section
      className="relative w-auto"
      style={vw ? { marginLeft: `calc(50% - ${vw / 2}px)`, marginRight: `calc(50% - ${vw / 2}px)` } : undefined}
    >
      <div className="flex flex-col md:flex-row gap-3 md:gap-4">
        {reverse ? (
          <>
            {imageCol}
            {videoCol}
          </>
        ) : (
          <>
            {videoCol}
            {imageCol}
          </>
        )}
      </div>
    </section>
  );
}

// Full-width video. `driftUp` makes it slowly translate upward as the
// page scrolls past it (used for the closing section); otherwise it's
// just a plain static full-width video (used for the section 3 static video).
function FullWidthVideo({ src, driftUp }) {
  const sectionRef = useRef(null);
  const [offset, setOffset] = useState(0);
  const vw = useViewportWidth();

  useEffect(() => {
    if (!driftUp) return;
    const el = sectionRef.current;
    if (!el) return;

    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const total = rect.height + vh;
      const raw = (vh - rect.top) / total;
      const progress = Math.min(1, Math.max(0, raw));
      // Negative translateY = drifts upward as you scroll through it.
      setOffset(progress * -80);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [driftUp]);

  return (
    <div
      ref={sectionRef}
      className="relative w-auto overflow-hidden bg-[#EDEAE3]"
      style={vw ? { marginLeft: `calc(50% - ${vw / 2}px)`, marginRight: `calc(50% - ${vw / 2}px)` } : undefined}
    >
      <video
        src={src}
        className="block w-full h-[70vh] md:h-[90vh] object-cover"
        style={driftUp ? { transform: `translateY(${offset}px)` } : undefined}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
      />
    </div>
  );
}

// The two long images side by side (Section 4).
function LongImagePair({ images, onOpen }) {
  return (
    <div className="flex flex-col md:flex-row gap-4 md:gap-6">
      {images.map((img) => (
        <button
          key={img.src}
          type="button"
          onClick={() => onOpen(img.mediaIndex)}
          aria-label={`Zoom in on ${img.alt}`}
          className="block w-full md:w-1/2 cursor-pointer focus:outline-none overflow-hidden bg-[#EDEAE3]"
        >
          <img src={img.src} alt={img.alt} className="block w-full h-[60vh] md:h-[85vh] object-cover" />
        </button>
      ))}
    </div>
  );
}

function ScrollStoryLayout({ onOpen }) {
  const findIndex = (src) => mediaItems.findIndex((m) => m.src === src);

  const section1Video = { src: "/Creative visuals/A6-R3-HQ.mp4" };
  const section1Images = [
    "/Creative visuals/RG01-Y-B-V2.png",
    "/Creative visuals/Beauty.png",
    "/Creative visuals/Earring 1 YG BlackBG V0001.png",
    "/Creative visuals/NB-1 LO R.png",
  ].map((src) => ({ src, alt: mediaItems[findIndex(src)]?.alt ?? "", mediaIndex: findIndex(src) }));

  const section2Video = { src: "/Creative visuals/M-Video.mp4" };
  const section2Images = [
    "/Creative visuals/R1-L2-P1-SB-Y-V4.png",
    "/Creative visuals/RG01-Y-B-V4.png",
    "/Creative visuals/Ring 2-Color BG-V1-R6.png",
    "/Creative visuals/Screenshot 2023-07-15 183627.png",
  ].map((src) => ({ src, alt: mediaItems[findIndex(src)]?.alt ?? "", mediaIndex: findIndex(src) }));

  const section3Video = { src: "/Creative visuals/B4 ANimated.mp4" };
  const section5Video = { src: "/Creative visuals/360 Turntable black.mp4" };

  const section4Images = [
    "/Creative visuals/Screenshot 2024-06-24 184639.png",
    "/Creative visuals/Screenshot 2023-12-20 080659.png",
  ].map((src) => ({ src, alt: mediaItems[findIndex(src)]?.alt ?? "", mediaIndex: findIndex(src) }));

  return (
    <div className="flex flex-col gap-16 md:gap-24">
      <FullWidthVideoWithImagesBelow video={section1Video} images={section1Images} onOpen={onOpen} />
      <VideoWithImages video={section2Video} images={section2Images} onOpen={onOpen} reverse={true} />
      <FullWidthVideo src={section3Video.src} />
      <LongImagePair images={section4Images} onOpen={onOpen} />
      <FullWidthVideo src={section5Video.src} driftUp />
    </div>
  );
}

export default function CreativeVisualsPage() {
  const { activeIndex, openAt, close, prev, next } = useLightbox(mediaItems);
  const [isOrbitLayout, setIsOrbitLayout] = useState(false);
  const [silkOn, setSilkOn] = useState(true);

  return (
    <ServicePageLayout title="Creative Visuals" currentPage="/creative-visuals" fullBleed>
      {/* Fixed, full-viewport Silk background — same treatment as Classic
          E-Commerce Visuals: sits behind page content, doesn't scroll,
          never intercepts clicks/scroll. z-0 (not a negative z-index) so
          it paints above ServicePageLayout's own root gradient but below
          this page's z-10 content wrapper. */}
      {silkOn && (
        <div className="fixed inset-0 z-0 pointer-events-none">
          <Silk speed={10} scale={1} color="#633c3c" noiseIntensity={2} rotation={0} />
        </div>
      )}

      {/* Silk on/off toggle */}
      <button
        onClick={() => setSilkOn((v) => !v)}
        className="
          fixed bottom-6 right-6 z-50
          font-[Manrope] text-[11px] tracking-[0.15em] font-semibold uppercase
          px-4 py-2.5
          bg-[#121212] text-[#FAF9F6] hover:bg-[#C5A059]
          border border-white/10 shadow-lg
          transition-colors duration-300
        "
      >
        Silk: {silkOn ? "On" : "Off"}
      </button>

      {/* Nav bar + cinematic hero, same treatment as Classic E-Commerce */}
      <HeroSection
        backgroundSrc="/Creative visuals/4 Ring Banner T4 HQ_.jpg"
        heading={["Creative", "Visuals"]}
        paragraph="A cascading edit of jewellery photography and motion — an interlocking mosaic of every piece."
      />

      <div
        className={`relative z-10 mx-auto overflow-x-hidden ${
          isOrbitLayout
            ? "px-2 sm:px-3 md:px-4 pb-10 md:pb-14"
            : "px-4 sm:px-6 md:px-10 lg:px-16 pb-40 md:pb-56"
        }`}
      >
        {isOrbitLayout ? (
          <div className="relative">
            {/* Icon-only layout toggle, overlaid top-right like the reference */}
            <button
              type="button"
              onClick={() => setIsOrbitLayout((prev) => !prev)}
              aria-label="Switch to grid view"
              title="Switch to grid view"
              className="absolute top-3 right-3 z-20 flex items-center justify-center w-9 h-9 bg-[#FAF9F6] text-[#121212] border border-[#121212]/15 hover:bg-[#121212] hover:text-[#FAF9F6] transition-colors duration-300"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.75"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-4 h-4"
              >
                <path d="M21 12a9 9 0 0 1-15.3 6.4M3 12a9 9 0 0 1 15.3-6.4" />
                <path d="M3 3v6h6" />
                <path d="M21 21v-6h-6" />
              </svg>
            </button>
            <OrbitGrid items={mediaItems} onOpen={openAt} />
          </div>
        ) : (
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsOrbitLayout((prev) => !prev)}
              className="absolute top-3 right-3 z-20 font-[Manrope] text-[11px] tracking-[0.15em] font-semibold uppercase px-5 py-2.5 bg-[#FAF9F6] border border-[#121212]/25 text-[#121212] hover:bg-[#121212] hover:text-[#FAF9F6] transition-colors duration-300"
            >
              Orbit View
            </button>
            <ScrollStoryLayout onOpen={openAt} />
          </div>
        )}
      </div>

      <LightboxModal
        images={mediaItems.map((m) => ({ src: m.src, alt: m.alt, isVideo: m.type === "video" }))}
        activeIndex={activeIndex}
        onClose={close}
        onPrev={prev}
        onNext={next}
      />
    </ServicePageLayout>
  );
}