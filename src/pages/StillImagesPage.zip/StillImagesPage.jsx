import { useEffect, useRef } from 'react'
import { ServicePageLayout } from '@/components/shared/ServicePageLayout'
import { StillImagesGrid } from '../components/shared/StillImagesGrid' // Assuming StillImagesGrid resides in the same directory

/* ─── Dynamic Image Pool (1 Hero + 40 Curated Non-Ring Assets) ─── */
const IMGS = [
  { src: 'cinegem jewellery.png', alt: 'Luxury pendant hero shot' }, // Index 0: Kept untouched for Section 1 Hero
  
  // Row 1 (Items 1-4)
  { src: '1.png', alt: 'Gold pendant minimalist profile' },
  { src: '2.png', alt: 'Gold pendant minimalist profile' },
    { src: '3.png', alt: 'Gold pendant minimalist profile' },
      { src: '4.png', alt: 'Gold pendant minimalist profile' },
  
  // Row 2 (Items 5-8)
  { src: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=600&auto=format&fit=cover', alt: 'Rose gold heavy link chain layout' },
  { src: 'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&auto=format&fit=cover', alt: 'Imperial jade bangle set' },
  { src: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=600&auto=format&fit=cover', alt: 'Opal crystal prism dispersion macro' },
  { src: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=cover', alt: 'Deep tanzanite studio lighting plate' },
  
  // Row 3 (Items 9-12)
  { src: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&auto=format&fit=cover', alt: 'Garnet dynamic visual portrait' },
  { src: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&auto=format&fit=cover', alt: 'Aquamarine fine polished layout' },
  { src: 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=600&auto=format&fit=cover', alt: 'Sleeping beauty turquoise custom item' },
  { src: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=600&auto=format&fit=cover', alt: 'Morganite cushion-cut drop necklace' },
  
  // Row 4 (Items 13-16)
  { src: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&auto=format&fit=cover', alt: 'Baltic amber organic specimen' },
  { src: 'https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?w=600&auto=format&fit=cover', alt: 'Bi-color tourmaline raw slice link' },
  { src: 'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&auto=format&fit=cover', alt: 'Adularia moonstone blue flash' },
  { src: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=600&auto=format&fit=cover', alt: 'Lapis lazuli deep matte setting' },
  
  // Row 5 (Items 17-20)
  { src: 'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&auto=format&fit=cover', alt: 'Golden sheen obsidian block item' },
  { src: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=600&auto=format&fit=cover', alt: 'Chrysoprase imperial translucent apple' },
  { src: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=cover', alt: 'Malachite precision orbit lines' },
  { src: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&auto=format&fit=cover', alt: 'Sunstone schiller aventurescence matrix' },
  
  // Row 6 (Items 21-24)
  { src: 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=600&auto=format&fit=cover', alt: 'Kunzite premium pink pleochroism' },
  { src: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=600&auto=format&fit=cover', alt: 'Tsavorite garnet chrome green element' },
  { src: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&auto=format&fit=cover', alt: 'Demantoid fire horseshoe arrangement' },
  { src: 'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&auto=format&fit=cover', alt: 'Princess cut modern layout array' },
  
  // Row 7 (Items 25-28)
  { src: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=600&auto=format&fit=cover', alt: 'Baguette channel alignment geometry' },
  { src: 'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&auto=format&fit=cover', alt: 'Rose diamond setting detail' },
  { src: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=600&auto=format&fit=cover', alt: 'Old mine cushion vintage macro' },
  { src: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=cover', alt: 'Heart pavilion pavé alignment map' },
  
  // Row 8 (Items 29-32)
  { src: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&auto=format&fit=cover', alt: 'Smooth cabochon lapis statement layout' },
  { src: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&auto=format&fit=cover', alt: 'Amethyst custom cut raw gem setup' },
  { src: 'https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=600&auto=format&fit=cover', alt: 'Topaz silver bezel placement' },
  { src: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&auto=format&fit=cover', alt: 'Citrine quartz vintage cocktail configuration' },
  
  // Row 9 (Items 33-36)
  { src: 'https://images.unsplash.com/photo-1602751584552-8ba73aad10e1?w=600&auto=format&fit=cover', alt: 'Black onyx custom geometric collection' },
  { src: 'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&auto=format&fit=cover', alt: 'Rutilated quartz clean studio frame' },
  { src: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=600&auto=format&fit=cover', alt: 'Mahenge spinel cushion facet matrix' },
  { src: 'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&auto=format&fit=cover', alt: 'Blue zircon high dispersion crown arrangement' },
  
  // Row 10 (Items 37-40)
  { src: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=600&auto=format&fit=cover', alt: 'Ametrine unique zoning raw jewel assembly' },
  { src: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&auto=format&fit=cover', alt: 'Chrysoberyl alexandrite shift element' },
  { src: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&auto=format&fit=cover', alt: 'Water sapphire iolite custom mounting array' },
  { src: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&auto=format&fit=cover', alt: 'South sea pearl strand setup frame' }
]

/* ─── Shared card frame style ─────────────────────────────────────────── */
const cardFrame = {
  padding: '8px',
  background: 'rgba(255,255,255,0.75)',
  backdropFilter: 'blur(12px) saturate(110%)',
  WebkitBackdropFilter: 'blur(12px) saturate(110%)',
  borderRadius: '5px',
  border: '0.5px solid rgba(255,255,255,0.50)',
  boxShadow:
    '0 12px 32px -8px rgba(18,18,18,0.10), 0 0 18px 1px rgba(255,255,255,0.30), inset 0 0 8px rgba(255,255,255,0.92)',
}

const imgInner = {
  position: 'relative',
  width: '100%',
  height: '100%',
  overflow: 'hidden',
  borderRadius: '2px',
  background: 'linear-gradient(135deg,#e8e0d4 0%,#d4cbbf 100%)',
}

const sheen = {
  position: 'absolute',
  inset: 0,
  background:
    'linear-gradient(135deg,transparent 30%,rgba(255,255,255,0.16) 50%,transparent 70%)',
  pointerEvents: 'none',
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION 1: HERO — UNTOUCHED
═══════════════════════════════════════════════════════════════════════════ */
function ScrollZoomHero() {
  const anchorRef = useRef(null)
  const cardRef   = useRef(null)

  useEffect(() => {
    const anchor = anchorRef.current
    const card   = cardRef.current
    if (!anchor || !card) return
    let raf = null
    const update = () => {
      const rect     = anchor.getBoundingClientRect()
      const vh       = window.innerHeight
      const progress = 1 - (rect.bottom / (vh + rect.height))
      const clamped  = Math.max(0, Math.min(1, progress))
      card.style.transform = `scale(${1.0 - clamped * 0.50})`
    }
    const onScroll = () => { if (raf) cancelAnimationFrame(raf); raf = requestAnimationFrame(update) }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => { window.removeEventListener('scroll', onScroll); if (raf) cancelAnimationFrame(raf) }
  }, [])

  return (
    <div ref={anchorRef} style={{ width: '100%', marginBottom: '4rem', position: 'relative', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <div ref={cardRef} style={{ width: '100%', maxWidth: '420px', aspectRatio: '9 / 16', ...cardFrame, padding: '12px', transformOrigin: 'center center', transform: 'scale(1)', willChange: 'transform', transition: 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)' }}>
        <div style={{ ...imgInner, height: '100%' }}>
          <img src={IMGS[0].src} alt={IMGS[0].alt} style={{ width: '100%', height: '100%', objectFit: 'contain', background: '#f4f1eb', display: 'block' }} />
          <div style={sheen} />
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION 3: HORIZONTAL SCROLL ROW — UNTOUCHED
═══════════════════════════════════════════════════════════════════════════ */
const ROW_IMGS = [...IMGS, ...IMGS]

function HScrollRow() {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', padding: '24px 0' }}>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: 80, background: 'linear-gradient(to right, #fbf9f1, transparent)', zIndex: 10, pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', top: 0, bottom: 0, right: 0, width: 80, background: 'linear-gradient(to left, #fbf9f1, transparent)', zIndex: 10, pointerEvents: 'none' }} />
      <div
        style={{ display: 'flex', gap: 14, width: 'max-content', animation: 'hScroll 28s linear infinite' }}
        onMouseEnter={e => (e.currentTarget.style.animationPlayState = 'paused')}
        onMouseLeave={e => (e.currentTarget.style.animationPlayState = 'running')}
      >
        {ROW_IMGS.map((img, i) => (
          <div
            key={i}
            style={{ flexShrink: 0, width: 130, height: 96, ...cardFrame, cursor: 'default', transition: 'transform 0.5s cubic-bezier(0.16,1,0.3,1), box-shadow 0.5s' }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = 'scale(1.07) translateY(-3px)'
              e.currentTarget.style.boxShadow = '0 20px 45px -10px rgba(18,18,18,0.15), 0 0 30px 4px rgba(197,160,89,0.12), inset 0 0 10px rgba(255,255,255,0.95)'
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = 'scale(1) translateY(0)'
              e.currentTarget.style.boxShadow = cardFrame.boxShadow
            }}
          >
            <div style={imgInner}>
              <img src={img.src} alt={img.alt} loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
              <div style={sheen} />
            </div>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes hScroll {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  )
}

/* ═══════════════════════════════════════════════════════════════════════════
   PAGE HERO — UNTOUCHED
═══════════════════════════════════════════════════════════════════════════ */
function PageHero() {
  return (
    <header style={{ marginBottom: '4rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      <span style={{ fontFamily: 'Manrope, system-ui, sans-serif', fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.22em', textTransform: 'uppercase', color: '#C5A059' }}>
        Still Imagery
      </span>
      <h1 style={{ fontFamily: '"Playfair Display", Georgia, serif', fontSize: 'clamp(2.4rem, 4.5vw, 4rem)', fontWeight: 400, color: '#121212', lineHeight: 1.06, letterSpacing: '-0.02em', maxWidth: '22ch', margin: 0 }}>
        Light frozen in<br /><em>perfect precision.</em>
      </h1>
      <div style={{ width: 64, height: 1, background: '#C5A059' }} />
      <p style={{ fontFamily: 'Manrope, system-ui, sans-serif', fontSize: '1rem', color: '#444748', lineHeight: 1.6, maxWidth: '44ch', margin: 0 }}>
        Hyper-realistic CGI stills rendered with raytraced precision — every facet,
        reflection, and surface texture crafted to evoke the material truth of your finest pieces.
      </p>
    </header>
  )
}

/* ═══════════════════════════════════════════════════════════════════════════
   PAGE ROOT
═══════════════════════════════════════════════════════════════════════════ */
export default function StillImagesPage() {
  // Extract exactly 40 non-hero items out of our asset pool array
  const gridImages = IMGS.slice(1)

  return (
    <ServicePageLayout title="Still Images">
      <PageHero />
      <ScrollZoomHero />

      {/* SECTION 2: Dynamic Grid Section integrating our advanced, static 4-column component */}
      <div style={{ margin: '0 -1.5rem 0', position: 'relative' }}>
        <StillImagesGrid images={gridImages} />
      </div>

      <div style={{ marginBottom: '1rem', paddingLeft: 0, marginTop: '4rem' }}>
        <span style={{ fontFamily: 'Manrope, system-ui, sans-serif', fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.2em', textTransform: 'uppercase', color: '#747878', opacity: 0.7 }}>
          Portfolio Highlights
        </span>
        <div style={{ marginTop: 8, width: 48, height: 1, background: 'rgba(197,160,89,0.5)' }} />
      </div>

      <div style={{ margin: '0 -1.5rem 5rem' }}>
        <HScrollRow />
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid rgba(196,199,199,0.3)', paddingTop: '3rem' }}>
        <div>
          <p style={{ fontFamily: '"Playfair Display", Georgia, serif', fontSize: 'clamp(1.3rem, 2vw, 1.8rem)', color: '#121212', margin: '0 0 0.5rem' }}>
            Ready to see your jewels in a new light?
          </p>
          <p style={{ fontFamily: 'Manrope, system-ui, sans-serif', fontSize: '0.95rem', color: '#444748', margin: 0 }}>
            Let's discuss your still imagery brief.
          </p>
        </div>
        <a
          href="/#contact"
          style={{ display: 'inline-block', fontFamily: 'Manrope, system-ui, sans-serif', fontSize: '0.65rem', fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', padding: '1rem 2rem', background: '#121212', color: '#FAF9F6', textDecoration: 'none', transition: 'background 0.3s' }}
          onMouseEnter={e => (e.currentTarget.style.background = '#C5A059')}
          onMouseLeave={e => (e.currentTarget.style.background = '#121212')}
        >
          Inquire →
        </a>
      </div>
    </ServicePageLayout>
  )
}